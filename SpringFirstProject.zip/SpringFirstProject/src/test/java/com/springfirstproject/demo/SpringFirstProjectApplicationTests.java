package com.springfirstproject.demo;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SpringFirstProjectApplicationTests {

    @Test
    void contextLoads() {
    }

}
